import azure.cognitiveservices.speech as speechsdk
from azure.ai.openai import OpenAIClient
from azure.identity import DefaultAzureCredential

# ----------------------------
# SPEECH CONFIG
# ----------------------------
speech_key = "11eBsSLDZCoKSWdJaj8uJBLw4GH9gCivLMJgSN2t0H4ev8Zfifs5JQQJ99BJACGhslBXJ3w3AAAYACOG6ag6"
service_region = "centralindia"

speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config)
speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config)

# ----------------------------
# AZURE OPENAI CONFIG
# ----------------------------
openai_endpoint = "https://YOUR_OPENAI_RESOURCE.openai.azure.com/"
openai_key = "YOUR_OPENAI_KEY"
client = OpenAIClient(openai_endpoint, credential=DefaultAzureCredential())

target_languages = ["Hindi", "French"]  # Languages you want

# ----------------------------
# TRANSLATION FUNCTION
# ----------------------------
def translate_with_openai(text, language):
    prompt = f"Translate the following text to {language}: {text}"
    response = client.chat_completions.create(
        deployment_name="gpt-35-turbo",  # your deployment name
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content.strip()

# ----------------------------
# CALLBACK FUNCTION
# ----------------------------
def recognized(evt):
    original_text = evt.result.text
    print(f"Recognized: {original_text}")

    for lang in target_languages:
        try:
            translated_text = translate_with_openai(original_text, lang)
            print(f"[{lang}] Translated: {translated_text}")
            speech_synthesizer.speak_text_async(translated_text)
        except Exception as e:
            print(f"Error translating to {lang}: {e}")

# ----------------------------
# START RECOGNITION
# ----------------------------
speech_recognizer.recognized.connect(recognized)
speech_recognizer.start_continuous_recognition()
print("Listening... Press Ctrl+C to stop.")

try:
    while True:
        pass
except KeyboardInterrupt:
    speech_recognizer.stop_continuous_recognition()
    print("Stopped.")
