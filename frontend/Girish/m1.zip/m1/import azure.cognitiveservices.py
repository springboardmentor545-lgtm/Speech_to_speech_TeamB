import azure.cognitiveservices.speech as speechsdk

# Your friend's API credentials
speech_key = "11eBsSLDZCoKSWdJaj8uJBLw4GH9gCivLMJgSN2t0H4ev8Zfifs5JQQJ99BJACGhslBXJ3w3AAAYACOG6ag6"
service_region = "india-central"  # e.g. "eastus"

speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config)

print("Speak now...")

def recognized(evt):
    print(f"Recognized: {evt.result.text}")

speech_recognizer.recognized.connect(recognized)
speech_recognizer.start_continuous_recognition()

try:
    while True:
        pass
except KeyboardInterrupt:
    speech_recognizer.stop_continuous_recognition()
    print("Stopped.")
