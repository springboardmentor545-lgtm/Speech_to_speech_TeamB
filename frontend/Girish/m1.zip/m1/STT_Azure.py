import azure.cognitiveservices.speech as speechsdk

# ----------------------------
# Azure Speech Configuration
# ----------------------------
speech_key = "11eBsSLDZCoKSWdJaj8uJBLw4GH9gCivLMJgSN2t0H4ev8Zfifs5JQQJ99BJACGhslBXJ3w3AAAYACOG6ag6"
service_region = "centralIndia"  # example region

speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
speech_config.speech_recognition_language = "ta-IN"  # or "hi-IN" for Hindi, etc.

# Create recognizer (uses your microphone by default)
speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config)

# ----------------------------
# Callback for recognized speech
# ----------------------------
def recognized(evt):
    if evt.result.text:
        print(f"Subtitle: {evt.result.text}")

# ----------------------------
# Start Recognition
# ----------------------------
speech_recognizer.recognized.connect(recognized)
speech_recognizer.start_continuous_recognition()

print("🎙️ Listening for speech... press Ctrl+C to stop.")

try:
    while True:
        pass
except KeyboardInterrupt:
    speech_recognizer.stop_continuous_recognition()
    print("\n🛑 Recognition stopped.")
