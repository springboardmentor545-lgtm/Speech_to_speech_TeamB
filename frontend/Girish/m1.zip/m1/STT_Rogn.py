import azure.cognitiveservices.speech as speechsdk
import datetime
import os

# ======================
# CONFIGURATION
# ======================
speech_key = "11eBsSLDZCoKSWdJaj8uJBLw4GH9gCivLMJgSN2t0H4ev8Zfifs5JQQJ99BJACGhslBXJ3w3AAAYACOG6ag6"
service_region = "CentralIndia"

# You can list more languages here (max 4 for auto-detection)
auto_detect_source_language_config = speechsdk.languageconfig.AutoDetectSourceLanguageConfig(
    languages=["en-IN", "hi-IN"]
)

# ======================
# OUTPUT SETUP
# ======================
output_dir = "collected_speech_data"
os.makedirs(output_dir, exist_ok=True)
timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
output_file = os.path.join(output_dir, f"speech_detected_{timestamp}.txt")

print(f"Saving recognized text + detected language to: {output_file}\n")
print("Speak something (say 'stop' to end)...\n")

# ======================
# SPEECH RECOGNIZER
# ======================
speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
speech_recognizer = speechsdk.SpeechRecognizer(
    speech_config=speech_config,
    auto_detect_source_language_config=auto_detect_source_language_config
)

with open(output_file, "w", encoding="utf-8") as f:
    while True:
        print("Listening...")
        result = speech_recognizer.recognize_once_async().get()

        if result.reason == speechsdk.ResultReason.RecognizedSpeech:
            text = result.text.strip()

            # Get detected language
            detected_lang = result.properties[
                speechsdk.PropertyId.SpeechServiceConnection_AutoDetectSourceLanguageResult
            ]
            print(f"Recognized: {text}")
            print(f"Detected Language: {detected_lang}\n")

            f.write(f"Detected: {detected_lang}\nText: {text}\n\n")

            if "stop" in text.lower():
                print("Stopping recognition...")
                break

        elif result.reason == speechsdk.ResultReason.NoMatch:
            print("No speech recognized. Try again.\n")

        elif result.reason == speechsdk.ResultReason.Canceled:
            cancellation = result.cancellation_details
            print(f"Speech recognition canceled: {cancellation.reason}")
            if cancellation.reason == speechsdk.CancellationReason.Error:
                print(f"Error details: {cancellation.error_details}")
            break

print(f"\nSpeech data saved to: {output_file}")
